#!/usr/bin/env python3
"""
BTC Trading System - Main Orchestration Script

This script:
1. Fetches 15-minute BTC OHLCV data from Binance
2. Calculates all technical indicators
3. Computes weighted trading scores (mirrors TradingView Pine Script v6)
4. Uploads results to Airtable
5. Optionally sends alerts to Slack

Usage:
    python main.py                              # Run once with Full System mode
    python main.py --mode scalper               # Run with Scalper preset
    python main.py --mode swing_trader          # Run with Swing Trader preset
    python main.py --continuous                 # Run continuously every 15 minutes
    python main.py --dry-run                    # Test without uploading to Airtable
"""

import argparse
import time
import logging
from datetime import datetime
from typing import Optional

from scoring_engine import (
    ScoringEngine, 
    WeightConfig, 
    IndicatorState,
    calculate_indicators_from_ohlcv,
    Signal,
    EntryMode,
    get_preset_weights,
    PRESET_DESCRIPTIONS
)
from data_fetcher import (
    BinanceDataFetcher,
    CoinalyzeDataFetcher,
    calculate_key_levels,
    detect_swing_levels
)
from airtable_client import (
    AirtableClient,
    AirtableConfig,
    format_score_breakdown_for_airtable
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Entry mode mapping from CLI to enum
ENTRY_MODE_MAP = {
    'full_system': EntryMode.FULL_SYSTEM,
    'price_action': EntryMode.PRICE_ACTION_ONLY,
    'momentum': EntryMode.MOMENTUM_ONLY,
    'volume_profile': EntryMode.VOLUME_PROFILE_ONLY,
    'scalper': EntryMode.SCALPER,
    'swing_trader': EntryMode.SWING_TRADER,
    'breakout_hunter': EntryMode.BREAKOUT_HUNTER,
    'conservative': EntryMode.CONSERVATIVE,
    'custom': EntryMode.CUSTOM,
}


class TradingPipeline:
    """Main trading data pipeline"""
    
    def __init__(
        self,
        weights: Optional[WeightConfig] = None,
        entry_mode: Optional[EntryMode] = None,
        dry_run: bool = False
    ):
        self.binance = BinanceDataFetcher()
        self.coinalyze = CoinalyzeDataFetcher()
        
        # Use entry mode preset if specified, otherwise use custom weights
        if entry_mode and entry_mode != EntryMode.CUSTOM:
            self.entry_mode = entry_mode
            self.scoring = ScoringEngine(entry_mode=entry_mode)
            logger.info(f"Using entry mode: {entry_mode.value}")
            logger.info(f"  Description: {PRESET_DESCRIPTIONS.get(entry_mode, 'N/A')}")
        else:
            self.entry_mode = EntryMode.CUSTOM
            self.scoring = ScoringEngine(weights=weights)
            logger.info("Using custom weights configuration")
        
        self.dry_run = dry_run
        
        if not dry_run:
            try:
                self.airtable = AirtableClient()
            except ValueError as e:
                logger.warning(f"Airtable not configured: {e}")
                self.airtable = None
        else:
            self.airtable = None
    
    def fetch_and_calculate(self) -> dict:
        """
        Fetch data and calculate all indicators and scores.
        
        Returns:
            Dictionary with all calculated values
        """
        logger.info("Fetching BTC 15m data from Binance...")
        df = self.binance.fetch_klines(interval="15m", limit=200)
        
        if df.empty:
            raise ValueError("No data received from Binance")
        
        logger.info(f"Got {len(df)} candles, latest: {df['timestamp'].iloc[-1]}")
        
        # Calculate basic indicators
        logger.info("Calculating indicators...")
        state = calculate_indicators_from_ohlcv(df)
        
        # Calculate key levels
        key_levels = calculate_key_levels(df)
        state.daily_open = key_levels.get('daily_open', 0)
        state.weekly_open = key_levels.get('weekly_open', 0)
        state.monthly_open = key_levels.get('monthly_open', 0)
        state.prev_day_high = key_levels.get('prev_day_high', 0)
        state.prev_day_low = key_levels.get('prev_day_low', 0)
        state.prev_week_high = key_levels.get('prev_week_high', 0)
        state.prev_week_low = key_levels.get('prev_week_low', 0)
        
        # Detect swing levels
        swing_levels = detect_swing_levels(df)
        state.swing_high_top = swing_levels.get('swing_high_top')
        state.swing_low_btm = swing_levels.get('swing_low_btm')
        state.swing_high_broken = swing_levels.get('swing_high_broken', False)
        state.swing_low_broken = swing_levels.get('swing_low_broken', False)
        state.swing_high_breakout = swing_levels.get('swing_high_breakout', False)
        state.swing_low_breakout = swing_levels.get('swing_low_breakout', False)
        state.swing_high_proximity = swing_levels.get('swing_high_proximity', False)
        state.swing_low_proximity = swing_levels.get('swing_low_proximity', False)
        
        # Detect breakouts
        close = df['close'].iloc[-1]
        prev_close = df['close'].iloc[-2]
        
        if state.prev_day_high:
            state.pdh_break = close > state.prev_day_high and prev_close <= state.prev_day_high
        if state.prev_day_low:
            state.pdl_break = close < state.prev_day_low and prev_close >= state.prev_day_low
        if state.prev_week_high:
            state.pwh_break = close > state.prev_week_high and prev_close <= state.prev_week_high
        if state.prev_week_low:
            state.pwl_break = close < state.prev_week_low and prev_close >= state.prev_week_low
        
        # Calculate scores
        logger.info("Calculating trading scores...")
        breakdown = self.scoring.calculate_total_score(state)
        
        # Build result
        result = {
            "timestamp": datetime.now().isoformat(),
            "btc_price": state.close,
            "state": state,
            "breakdown": breakdown,
            "key_levels": key_levels,
            "swing_levels": swing_levels,
        }
        
        return result
    
    def upload_to_airtable(self, result: dict) -> Optional[dict]:
        """Upload results to Airtable"""
        if self.airtable is None:
            logger.warning("Airtable client not configured, skipping upload")
            return None
        
        logger.info("Uploading to Airtable...")
        
        breakdown = result["breakdown"]
        state = result["state"]
        
        # Get Coinalyze data if available
        coinalyze_data = self.coinalyze.get_data()
        
        # Build indicator states dict
        indicator_states = {
            "poc": state.poc,
            "vwap": state.vwap,
            "squeeze_active": state.squeeze_active,
            "normal_box_active": state.normal_box_active,
        }
        
        record = self.airtable.upload_trading_scores(
            btc_price=state.close,
            direction_score=breakdown.direction_weighted,
            momentum_score=breakdown.momentum_weighted,
            breakout_score=breakdown.breakout_weighted,
            price_action_score=breakdown.price_action_weighted,
            key_level_score=breakdown.key_level_weighted,
            total_score=breakdown.total_score,
            signal=breakdown.signal.value,
            coinalyze_data=coinalyze_data if coinalyze_data else None,
            indicator_states=indicator_states
        )
        
        logger.info(f"Uploaded to Airtable: {record.get('id', 'unknown')}")
        return record
    
    def upload_15min_signal(self, result: dict) -> Optional[dict]:
        """
        Upload 15-minute signal to signals table.
        
        This is separate from daily data - it produces BUY/SELL/STALL signals
        every 30 minutes (2 candles worth) for intraday trading.
        """
        if self.airtable is None:
            logger.warning("Airtable client not configured, skipping signal upload")
            return None
        
        if not self.airtable.config.signals_table_id:
            logger.warning("Signals table not configured (AIRTABLE_SIGNALS_TABLE_ID not set)")
            return None
        
        breakdown = result["breakdown"]
        state = result["state"]
        
        # Get daily context for macro confluence
        daily_context = self.airtable.get_latest_daily_context()
        
        # Determine signal (BUY/SELL/STALL)
        threshold = self.scoring.weights.entry_threshold if hasattr(self.scoring, 'weights') else 5.0
        signal = self.airtable.determine_signal(
            breakdown.total_score,
            threshold=threshold,
            daily_context=daily_context
        )
        
        # Build notes with any anomalies or context
        notes_parts = []
        
        # Check for confluence with daily data
        if daily_context:
            daily_tpi = daily_context.get("tpi", 0)
            if signal == "BUY" and daily_tpi < 0:
                notes_parts.append(f"⚠️ 15m BUY but daily TPI is {daily_tpi:.1f}")
            elif signal == "SELL" and daily_tpi > 0:
                notes_parts.append(f"⚠️ 15m SELL but daily TPI is {daily_tpi:.1f}")
            elif signal == "BUY" and daily_tpi > 5:
                notes_parts.append(f"✅ Strong confluence: daily TPI {daily_tpi:.1f}")
            elif signal == "SELL" and daily_tpi < -5:
                notes_parts.append(f"✅ Strong confluence: daily TPI {daily_tpi:.1f}")
        
        # Check individual category strengths
        if breakdown.breakout_weighted != 0:
            notes_parts.append(f"Breakout active: {breakdown.breakout_weighted:+.1f}")
        
        if state.squeeze_active:
            notes_parts.append("🎯 Squeeze building")
        
        logger.info(f"Uploading 15min signal: {signal} (score: {breakdown.total_score:.2f})")
        
        record = self.airtable.upload_15min_signal(
            btc_price=state.close,
            total_score=breakdown.total_score,
            signal=signal,
            entry_mode=self.entry_mode.value,
            direction_score=breakdown.direction_weighted,
            momentum_score=breakdown.momentum_weighted,
            breakout_score=breakdown.breakout_weighted,
            price_action_score=breakdown.price_action_weighted,
            key_level_score=breakdown.key_level_weighted,
            daily_tpi=daily_context.get("tpi") if daily_context else None,
            daily_oi_trend=daily_context.get("oi_trend") if daily_context else None,
            daily_funding=daily_context.get("funding") if daily_context else None,
            notes="\n".join(notes_parts) if notes_parts else ""
        )
        
        logger.info(f"Uploaded 15min signal: {record.get('id', 'unknown')}")
        return record
    
    def print_summary(self, result: dict):
        """Print a summary of the results"""
        breakdown = result["breakdown"]
        state = result["state"]
        
        print("\n" + "="*60)
        print(f"BTC TRADING SIGNAL - {result['timestamp']}")
        print("="*60)
        
        print(f"\n📊 BTC Price: ${state.close:,.2f}")
        
        print(f"\n📈 SCORE BREAKDOWN:")
        print(f"   Direction:    {breakdown.direction_weighted:+.2f}")
        print(f"   Momentum:     {breakdown.momentum_weighted:+.2f}")
        print(f"   Breakout:     {breakdown.breakout_weighted:+.2f}")
        print(f"   Price Action: {breakdown.price_action_weighted:+.2f}")
        print(f"   Key Levels:   {breakdown.key_level_weighted:+.2f}")
        print(f"   ─────────────────────")
        print(f"   TOTAL:        {breakdown.total_score:+.2f}")
        
        # Signal
        signal_emoji = {
            Signal.STRONG_BUY: "🟢🟢",
            Signal.LEAN_LONG: "🟢",
            Signal.NEUTRAL: "⚪",
            Signal.LEAN_SHORT: "🔴",
            Signal.STRONG_SELL: "🔴🔴",
        }
        
        print(f"\n🎯 SIGNAL: {signal_emoji.get(breakdown.signal, '')} {breakdown.signal.value}")
        
        # Key levels
        levels = result.get("key_levels", {})
        if levels:
            print(f"\n📍 KEY LEVELS:")
            if levels.get("daily_open"):
                print(f"   Daily Open:   ${levels['daily_open']:,.2f}")
            if levels.get("prev_day_high"):
                print(f"   PDH:          ${levels['prev_day_high']:,.2f}")
            if levels.get("prev_day_low"):
                print(f"   PDL:          ${levels['prev_day_low']:,.2f}")
            if levels.get("weekly_open"):
                print(f"   Weekly Open:  ${levels['weekly_open']:,.2f}")
        
        # Technical state
        print(f"\n🔧 INDICATORS:")
        print(f"   EMA 9:    ${state.ema9:,.2f} ({'above' if state.close > state.ema9 else 'below'})")
        print(f"   EMA 21:   ${state.ema21:,.2f} ({'above' if state.close > state.ema21 else 'below'})")
        print(f"   EMA 50:   ${state.ema50:,.2f} ({'above' if state.close > state.ema50 else 'below'})")
        print(f"   Squeeze:  {'ACTIVE' if state.squeeze_active else 'No'}")
        
        print("\n" + "="*60 + "\n")
    
    def run_once(self, upload_signals: bool = True) -> dict:
        """Run the pipeline once
        
        Args:
            upload_signals: If True and signals table configured, upload 15-min signals
        """
        result = self.fetch_and_calculate()
        self.print_summary(result)
        
        if not self.dry_run:
            # Upload daily data
            self.upload_to_airtable(result)
            
            # Upload 15-minute signals if configured
            if upload_signals:
                try:
                    self.upload_15min_signal(result)
                except Exception as e:
                    logger.warning(f"Failed to upload 15min signal: {e}")
        else:
            logger.info("Dry run - skipping Airtable upload")
        
        return result
    
    def run_continuous(self, interval_minutes: int = 30, upload_signals: bool = True):
        """Run the pipeline continuously
        
        Args:
            interval_minutes: Minutes between runs (default 30 = 2 candles)
            upload_signals: If True, upload 15-min signals each run
        """
        logger.info(f"Starting continuous mode, running every {interval_minutes} minutes")
        logger.info(f"Signal upload: {'enabled' if upload_signals else 'disabled'}")
        
        while True:
            try:
                self.run_once(upload_signals=upload_signals)
            except Exception as e:
                logger.error(f"Error in pipeline: {e}")
            
            # Wait for next interval
            next_run = datetime.now().replace(
                minute=(datetime.now().minute // interval_minutes + 1) * interval_minutes % 60,
                second=0,
                microsecond=0
            )
            wait_seconds = (next_run - datetime.now()).total_seconds()
            if wait_seconds < 0:
                wait_seconds += interval_minutes * 60
            
            logger.info(f"Next run in {wait_seconds:.0f} seconds...")
            time.sleep(wait_seconds)
    
    def set_coinalyze_data(self, **kwargs):
        """Set Coinalyze data from external source"""
        self.coinalyze.set_data(**kwargs)


def main():
    parser = argparse.ArgumentParser(
        description="BTC Trading System - Calculate and upload trading signals",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Entry Mode Presets:
  full_system      All indicators enabled with balanced weights (default)
  price_action     Swing breaks, PDH/PDL, PWH/PWL focus
  momentum         EMA trend, KC, BB, VWAP bands focus  
  volume_profile   POC, VAH/VAL, volume-based signals
  scalper          Fast signals: EMA, squeeze, volume spikes
  swing_trader     Larger moves: Weekly levels, EMA50, high R:R
  breakout_hunter  Box breaks, squeezes, swing breakouts
  conservative     High conviction: Multiple confirmations required

Examples:
  python main.py --mode scalper              # Quick scalp signals
  python main.py --mode swing_trader -c      # Continuous swing mode
  python main.py -d                          # Dry run (no upload)
"""
    )
    parser.add_argument(
        "--mode", "-m",
        type=str,
        default="full_system",
        choices=list(ENTRY_MODE_MAP.keys()),
        help="Entry mode preset (default: full_system)"
    )
    parser.add_argument(
        "--continuous", "-c",
        action="store_true",
        help="Run continuously every 30 minutes (2x 15min candles)"
    )
    parser.add_argument(
        "--dry-run", "-d",
        action="store_true",
        help="Test mode - don't upload to Airtable"
    )
    parser.add_argument(
        "--interval", "-i",
        type=int,
        default=30,
        help="Interval in minutes for continuous mode (default: 30)"
    )
    parser.add_argument(
        "--no-signals",
        action="store_true",
        help="Skip 15-minute signal uploads (only daily data)"
    )
    parser.add_argument(
        "--list-modes",
        action="store_true",
        help="List all available entry modes with descriptions"
    )
    
    args = parser.parse_args()
    
    # List modes if requested
    if args.list_modes:
        print("\n📊 Available Entry Modes:\n")
        for mode_key, mode_enum in ENTRY_MODE_MAP.items():
            desc = PRESET_DESCRIPTIONS.get(mode_enum, "N/A")
            weights = get_preset_weights(mode_enum)
            print(f"  {mode_key:20} {desc}")
            print(f"                       Entry threshold: {weights.entry_strength_min}, R:R min: {weights.rr_min}")
            print()
        return
    
    # Get entry mode enum
    entry_mode = ENTRY_MODE_MAP.get(args.mode, EntryMode.FULL_SYSTEM)
    
    # Create pipeline with entry mode
    pipeline = TradingPipeline(entry_mode=entry_mode, dry_run=args.dry_run)
    
    upload_signals = not args.no_signals
    
    if args.continuous:
        pipeline.run_continuous(interval_minutes=args.interval, upload_signals=upload_signals)
    else:
        pipeline.run_once(upload_signals=upload_signals)


if __name__ == "__main__":
    main()
