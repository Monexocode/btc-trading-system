"""
BTC Multi-Box Breakout Strategy - Python Scoring Engine
Converted from TradingView Pine Script v6

This module calculates trading signals based on a weighted scoring system
across 5 categories: Direction, Momentum, Breakout, Price Action, Key Levels.

Supports entry mode presets: Full System, Price Action Only, Momentum Only,
Volume Profile Only, Scalper, Swing Trader, Breakout Hunter, Conservative, Custom
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Tuple, Optional, Dict, List
from enum import Enum


class Signal(Enum):
    STRONG_BUY = "STRONG_BUY"
    LEAN_LONG = "LEAN_LONG"
    NEUTRAL = "NEUTRAL"
    LEAN_SHORT = "LEAN_SHORT"
    STRONG_SELL = "STRONG_SELL"


class EntryMode(Enum):
    """Entry mode presets from Pine Script v6"""
    FULL_SYSTEM = "Full System"
    PRICE_ACTION_ONLY = "Price Action Only"
    MOMENTUM_ONLY = "Momentum Only"
    VOLUME_PROFILE_ONLY = "Volume Profile Only"
    SCALPER = "Scalper"
    SWING_TRADER = "Swing Trader"
    BREAKOUT_HUNTER = "Breakout Hunter"
    CONSERVATIVE = "Conservative"
    CUSTOM = "Custom"


# Preset descriptions matching Pine Script
PRESET_DESCRIPTIONS = {
    EntryMode.FULL_SYSTEM: "All indicators enabled with balanced weights",
    EntryMode.PRICE_ACTION_ONLY: "Swing breaks, PDH/PDL, PWH/PWL focus",
    EntryMode.MOMENTUM_ONLY: "EMA trend, KC, BB, VWAP bands focus",
    EntryMode.VOLUME_PROFILE_ONLY: "POC, VAH/VAL, volume-based signals",
    EntryMode.SCALPER: "Fast signals: EMA, squeeze, volume spikes",
    EntryMode.SWING_TRADER: "Larger moves: Weekly levels, EMA50, high R:R",
    EntryMode.BREAKOUT_HUNTER: "Box breaks, squeezes, swing breakouts",
    EntryMode.CONSERVATIVE: "High conviction: Multiple confirmations",
    EntryMode.CUSTOM: "Manual configuration via settings below",
}


def get_preset_weights(mode: EntryMode) -> 'WeightConfig':
    """Get weight configuration for a specific entry mode preset"""
    
    if mode == EntryMode.FULL_SYSTEM:
        return WeightConfig(
            # Direction
            use_dir_poc=True, dir_poc=1.0,
            use_dir_vah_val=True, dir_vah_val=1.0,
            use_dir_ema9=True, dir_ema9=1.0,
            use_dir_ema21=True, dir_ema21=1.0,
            use_dir_ema50=True, dir_ema50=1.0,
            use_dir_box_break=True, dir_box_break=1.0,
            use_dir_volume=True, dir_volume=1.0,
            use_dir_vwap_rev=True, dir_vwap_rev=1.0,
            dir_category_weight=1.0,
            # Momentum
            use_mom_ema_trend=True, mom_ema_trend=1.0,
            use_mom_kc=True, mom_kc=1.0,
            use_mom_bb=True, mom_bb=1.0,
            use_mom_vwap_band=True, mom_vwap_band=1.0,
            use_mom_candle=True, mom_candle=1.0,
            mom_category_weight=1.0,
            # Breakout
            use_bo_squeeze=True, bo_squeeze=2.0,
            use_bo_box_pos=True, bo_box_pos=2.0,
            bo_category_weight=1.0,
            # Price Action
            use_pa_swing_high=True, pa_swing_high=2.0,
            use_pa_swing_low=True, pa_swing_low=2.0,
            use_pa_pdh_pdl=True, pa_pdh_pdl=1.5,
            use_pa_pwh_pwl=True, pa_pwh_pwl=1.5,
            use_pa_swing_proximity=False, pa_swing_proximity=1.0,
            pa_category_weight=1.0,
            # Key Levels
            use_kl_daily=False, kl_daily=1.0,
            use_kl_weekly=False, kl_weekly=1.0,
            use_kl_monthly=False, kl_monthly=1.0,
            use_kl_ny=False, kl_ny=1.0,
            use_kl_stack=False, kl_stack=2.0,
            kl_category_weight=1.0,
            entry_strength_min=5.0,
            volume_filter_mult=1.5,
            rr_min=1.5,
        )
    
    elif mode == EntryMode.SCALPER:
        return WeightConfig(
            # Direction - fast signals
            use_dir_poc=False, dir_poc=0.0,
            use_dir_vah_val=False, dir_vah_val=0.0,
            use_dir_ema9=True, dir_ema9=2.0,
            use_dir_ema21=True, dir_ema21=1.5,
            use_dir_ema50=False, dir_ema50=0.0,
            use_dir_box_break=True, dir_box_break=1.5,
            use_dir_volume=True, dir_volume=2.0,
            use_dir_vwap_rev=False, dir_vwap_rev=0.0,
            dir_category_weight=1.0,
            # Momentum
            use_mom_ema_trend=True, mom_ema_trend=2.0,
            use_mom_kc=True, mom_kc=1.5,
            use_mom_bb=True, mom_bb=1.5,
            use_mom_vwap_band=False, mom_vwap_band=0.0,
            use_mom_candle=True, mom_candle=1.0,
            mom_category_weight=1.5,
            # Breakout - high weight for squeezes
            use_bo_squeeze=True, bo_squeeze=3.0,
            use_bo_box_pos=True, bo_box_pos=2.0,
            bo_category_weight=1.5,
            # Price Action - minimal
            use_pa_swing_high=False, pa_swing_high=0.0,
            use_pa_swing_low=False, pa_swing_low=0.0,
            use_pa_pdh_pdl=True, pa_pdh_pdl=1.5,
            use_pa_pwh_pwl=False, pa_pwh_pwl=0.0,
            use_pa_swing_proximity=False, pa_swing_proximity=0.0,
            pa_category_weight=0.5,
            # Key Levels - NY focus
            use_kl_daily=False, kl_daily=0.0,
            use_kl_weekly=False, kl_weekly=0.0,
            use_kl_monthly=False, kl_monthly=0.0,
            use_kl_ny=True, kl_ny=1.5,
            use_kl_stack=False, kl_stack=0.0,
            kl_category_weight=0.5,
            entry_strength_min=3.0,
            volume_filter_mult=1.3,
            rr_min=1.0,
        )
    
    elif mode == EntryMode.SWING_TRADER:
        return WeightConfig(
            # Direction - higher timeframe focus
            use_dir_poc=True, dir_poc=1.0,
            use_dir_vah_val=False, dir_vah_val=0.0,
            use_dir_ema9=False, dir_ema9=0.0,
            use_dir_ema21=True, dir_ema21=1.0,
            use_dir_ema50=True, dir_ema50=2.0,
            use_dir_box_break=True, dir_box_break=1.5,
            use_dir_volume=False, dir_volume=0.0,
            use_dir_vwap_rev=False, dir_vwap_rev=0.0,
            dir_category_weight=1.0,
            # Momentum
            use_mom_ema_trend=True, mom_ema_trend=1.5,
            use_mom_kc=False, mom_kc=0.0,
            use_mom_bb=False, mom_bb=0.0,
            use_mom_vwap_band=False, mom_vwap_band=0.0,
            use_mom_candle=True, mom_candle=0.5,
            mom_category_weight=1.0,
            # Breakout
            use_bo_squeeze=False, bo_squeeze=0.0,
            use_bo_box_pos=True, bo_box_pos=2.0,
            bo_category_weight=1.0,
            # Price Action - swing focus
            use_pa_swing_high=True, pa_swing_high=2.0,
            use_pa_swing_low=True, pa_swing_low=2.0,
            use_pa_pdh_pdl=True, pa_pdh_pdl=2.0,
            use_pa_pwh_pwl=True, pa_pwh_pwl=2.5,
            use_pa_swing_proximity=True, pa_swing_proximity=1.0,
            pa_category_weight=1.5,
            # Key Levels - weekly/monthly
            use_kl_daily=True, kl_daily=1.0,
            use_kl_weekly=True, kl_weekly=1.5,
            use_kl_monthly=True, kl_monthly=2.0,
            use_kl_ny=False, kl_ny=0.0,
            use_kl_stack=True, kl_stack=2.0,
            kl_category_weight=1.5,
            entry_strength_min=5.0,
            volume_filter_mult=1.5,
            rr_min=2.0,
        )
    
    elif mode == EntryMode.BREAKOUT_HUNTER:
        return WeightConfig(
            # Direction - breakout focus
            use_dir_poc=False, dir_poc=0.0,
            use_dir_vah_val=False, dir_vah_val=0.0,
            use_dir_ema9=False, dir_ema9=0.0,
            use_dir_ema21=False, dir_ema21=0.0,
            use_dir_ema50=False, dir_ema50=0.0,
            use_dir_box_break=True, dir_box_break=2.5,
            use_dir_volume=True, dir_volume=1.5,
            use_dir_vwap_rev=False, dir_vwap_rev=0.0,
            dir_category_weight=0.5,
            # Momentum
            use_mom_ema_trend=False, mom_ema_trend=0.0,
            use_mom_kc=True, mom_kc=1.5,
            use_mom_bb=True, mom_bb=1.5,
            use_mom_vwap_band=False, mom_vwap_band=0.0,
            use_mom_candle=True, mom_candle=1.0,
            mom_category_weight=1.0,
            # Breakout - max weight
            use_bo_squeeze=True, bo_squeeze=3.0,
            use_bo_box_pos=True, bo_box_pos=3.0,
            bo_category_weight=2.0,
            # Price Action - breakouts
            use_pa_swing_high=True, pa_swing_high=3.0,
            use_pa_swing_low=True, pa_swing_low=3.0,
            use_pa_pdh_pdl=True, pa_pdh_pdl=2.0,
            use_pa_pwh_pwl=True, pa_pwh_pwl=2.0,
            use_pa_swing_proximity=True, pa_swing_proximity=1.5,
            pa_category_weight=1.5,
            # Key Levels
            use_kl_daily=False, kl_daily=0.0,
            use_kl_weekly=False, kl_weekly=0.0,
            use_kl_monthly=False, kl_monthly=0.0,
            use_kl_ny=False, kl_ny=0.0,
            use_kl_stack=False, kl_stack=0.0,
            kl_category_weight=0.5,
            entry_strength_min=4.0,
            volume_filter_mult=1.5,
            rr_min=1.5,
        )
    
    elif mode == EntryMode.CONSERVATIVE:
        return WeightConfig(
            # Direction - all enabled, higher weights
            use_dir_poc=True, dir_poc=1.5,
            use_dir_vah_val=True, dir_vah_val=1.5,
            use_dir_ema9=True, dir_ema9=1.0,
            use_dir_ema21=True, dir_ema21=1.0,
            use_dir_ema50=True, dir_ema50=1.5,
            use_dir_box_break=True, dir_box_break=1.5,
            use_dir_volume=True, dir_volume=1.0,
            use_dir_vwap_rev=True, dir_vwap_rev=1.0,
            dir_category_weight=1.0,
            # Momentum
            use_mom_ema_trend=True, mom_ema_trend=1.0,
            use_mom_kc=True, mom_kc=1.0,
            use_mom_bb=True, mom_bb=1.0,
            use_mom_vwap_band=True, mom_vwap_band=1.0,
            use_mom_candle=True, mom_candle=0.5,
            mom_category_weight=1.0,
            # Breakout
            use_bo_squeeze=True, bo_squeeze=2.0,
            use_bo_box_pos=True, bo_box_pos=2.0,
            bo_category_weight=1.0,
            # Price Action
            use_pa_swing_high=True, pa_swing_high=2.0,
            use_pa_swing_low=True, pa_swing_low=2.0,
            use_pa_pdh_pdl=True, pa_pdh_pdl=1.5,
            use_pa_pwh_pwl=True, pa_pwh_pwl=1.5,
            use_pa_swing_proximity=False, pa_swing_proximity=0.0,
            pa_category_weight=1.0,
            # Key Levels - all enabled
            use_kl_daily=True, kl_daily=1.5,
            use_kl_weekly=True, kl_weekly=1.5,
            use_kl_monthly=True, kl_monthly=2.0,
            use_kl_ny=False, kl_ny=0.0,
            use_kl_stack=True, kl_stack=2.5,
            kl_category_weight=1.5,
            entry_strength_min=7.0,  # Higher threshold
            volume_filter_mult=2.0,
            rr_min=2.0,
        )
    
    # Default to Full System for other modes
    return WeightConfig()


@dataclass
class WeightConfig:
    """Configurable weights for all indicators - matches TradingView v6 inputs"""
    
    # Direction Indicators - enable flags
    use_dir_poc: bool = True
    use_dir_vah_val: bool = True
    use_dir_ema9: bool = True
    use_dir_ema21: bool = True
    use_dir_ema50: bool = True
    use_dir_box_break: bool = True
    use_dir_volume: bool = True
    use_dir_vwap_rev: bool = True
    
    # Direction Indicator weights
    dir_poc: float = 1.0
    dir_vah_val: float = 1.0
    dir_ema9: float = 1.0
    dir_ema21: float = 1.0
    dir_ema50: float = 1.0
    dir_box_break: float = 1.0
    dir_volume: float = 1.0
    dir_vwap_rev: float = 1.0
    dir_category_weight: float = 1.0
    
    # Momentum Indicators - enable flags
    use_mom_ema_trend: bool = True
    use_mom_kc: bool = True
    use_mom_bb: bool = True
    use_mom_vwap_band: bool = True
    use_mom_candle: bool = True
    
    # Momentum Indicator weights
    mom_ema_trend: float = 1.0
    mom_kc: float = 1.0
    mom_bb: float = 1.0
    mom_vwap_band: float = 1.0
    mom_candle: float = 1.0
    mom_category_weight: float = 1.0
    
    # Breakout Indicators - enable flags
    use_bo_squeeze: bool = True
    use_bo_box_pos: bool = True
    
    # Breakout Indicator weights
    bo_squeeze: float = 2.0
    bo_box_pos: float = 2.0
    bo_category_weight: float = 1.0
    
    # Price Action Indicators - enable flags
    use_pa_swing_high: bool = True
    use_pa_swing_low: bool = True
    use_pa_pdh_pdl: bool = True
    use_pa_pwh_pwl: bool = True
    use_pa_swing_proximity: bool = False
    
    # Price Action Indicator weights
    pa_swing_high: float = 2.0
    pa_swing_low: float = 2.0
    pa_pdh_pdl: float = 1.5
    pa_pwh_pwl: float = 1.5
    pa_swing_proximity: float = 1.0
    pa_category_weight: float = 1.0
    
    # Key Level Confluence - enable flags
    use_kl_daily: bool = False
    use_kl_weekly: bool = False
    use_kl_monthly: bool = False
    use_kl_ny: bool = False
    use_kl_stack: bool = False
    
    # Key Level weights
    kl_daily: float = 1.0
    kl_weekly: float = 1.0
    kl_monthly: float = 1.0
    kl_ny: float = 1.0
    kl_stack: float = 2.0
    kl_category_weight: float = 1.0
    
    # Entry Filters
    entry_strength_min: float = 5.0
    volume_filter_mult: float = 1.5
    rr_min: float = 1.5


@dataclass 
class IndicatorState:
    """Current state of all indicators for scoring"""
    
    # Price data
    close: float = 0.0
    high: float = 0.0
    low: float = 0.0
    open: float = 0.0
    volume: float = 0.0
    
    # EMAs
    ema9: float = 0.0
    ema21: float = 0.0
    ema50: float = 0.0
    
    # Volume Profile
    poc: float = 0.0
    vah: float = 0.0
    val: float = 0.0
    vah_touched_today: bool = False
    val_touched_today: bool = False
    
    # VWAP
    vwap: float = 0.0
    vwap_upper_band: float = 0.0
    vwap_lower_band: float = 0.0
    
    # Bollinger Bands
    bb_upper: float = 0.0
    bb_lower: float = 0.0
    bb_width: float = 0.0
    
    # Keltner Channels
    kc_upper: float = 0.0
    kc_lower: float = 0.0
    
    # Box state
    normal_box_active: bool = False
    normal_box_high: float = 0.0
    normal_box_low: float = 0.0
    normal_box_break_up: bool = False
    normal_box_break_down: bool = False
    
    # Squeeze state
    squeeze_active: bool = False
    price_near_kc_upper: bool = False
    price_near_kc_lower: bool = False
    
    # Swing levels
    swing_high_top: Optional[float] = None
    swing_low_btm: Optional[float] = None
    swing_high_broken: bool = False
    swing_low_broken: bool = False
    swing_high_breakout: bool = False
    swing_low_breakout: bool = False
    swing_high_proximity: bool = False
    swing_low_proximity: bool = False
    
    # Key levels
    prev_day_high: float = 0.0
    prev_day_low: float = 0.0
    prev_week_high: float = 0.0
    prev_week_low: float = 0.0
    daily_open: float = 0.0
    weekly_open: float = 0.0
    monthly_open: float = 0.0
    ny_open: Optional[float] = None
    
    # Breakouts
    pdh_break: bool = False
    pdl_break: bool = False
    pwh_break: bool = False
    pwl_break: bool = False
    
    # Volume
    volume_avg: float = 0.0
    atr: float = 0.0
    
    # Candle quality
    close_in_upper_third: bool = False
    close_in_lower_third: bool = False


@dataclass
class ScoreBreakdown:
    """Detailed breakdown of scores by category"""
    
    # Direction scores
    dir_poc: float = 0.0
    dir_vah_val: float = 0.0
    dir_ema9: float = 0.0
    dir_ema21: float = 0.0
    dir_ema50: float = 0.0
    dir_box_break: float = 0.0
    dir_volume: float = 0.0
    dir_vwap_rev: float = 0.0
    direction_raw: float = 0.0
    direction_weighted: float = 0.0
    
    # Momentum scores
    mom_ema_trend: float = 0.0
    mom_kc: float = 0.0
    mom_bb: float = 0.0
    mom_vwap_band: float = 0.0
    mom_candle: float = 0.0
    momentum_raw: float = 0.0
    momentum_weighted: float = 0.0
    
    # Breakout scores
    bo_squeeze: float = 0.0
    bo_box_pos: float = 0.0
    breakout_raw: float = 0.0
    breakout_weighted: float = 0.0
    
    # Price action scores
    pa_swing_high: float = 0.0
    pa_swing_low: float = 0.0
    pa_pdh: float = 0.0
    pa_pdl: float = 0.0
    pa_pwh: float = 0.0
    pa_pwl: float = 0.0
    pa_swing_prox_high: float = 0.0
    pa_swing_prox_low: float = 0.0
    price_action_raw: float = 0.0
    price_action_weighted: float = 0.0
    
    # Key level scores
    kl_daily: float = 0.0
    kl_weekly: float = 0.0
    kl_monthly: float = 0.0
    kl_ny: float = 0.0
    kl_stack: float = 0.0
    key_level_raw: float = 0.0
    key_level_weighted: float = 0.0
    
    # Total
    total_score: float = 0.0
    signal: Signal = Signal.NEUTRAL
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for Airtable upload"""
        return {
            "Direction Score": round(self.direction_weighted, 2),
            "Momentum Score": round(self.momentum_weighted, 2),
            "Breakout Score": round(self.breakout_weighted, 2),
            "Price Action Score": round(self.price_action_weighted, 2),
            "Key Level Score": round(self.key_level_weighted, 2),
            "Total Score": round(self.total_score, 2),
            "Signal": self.signal.value,
        }


class ScoringEngine:
    """Main scoring engine - calculates weighted scores from indicator state"""
    
    def __init__(self, weights: Optional[WeightConfig] = None, entry_mode: Optional[EntryMode] = None):
        if entry_mode and entry_mode != EntryMode.CUSTOM:
            self.weights = get_preset_weights(entry_mode)
        else:
            self.weights = weights or WeightConfig()
        self.entry_mode = entry_mode or EntryMode.CUSTOM
    
    def calculate_direction_scores(self, state: IndicatorState) -> Tuple[float, Dict[str, float]]:
        """Calculate direction category scores"""
        w = self.weights
        scores = {}
        
        # POC position: +1 if above, -1 if below
        if w.use_dir_poc:
            raw_poc = 1.0 if state.close > state.poc else -1.0
            scores['dir_poc'] = raw_poc * w.dir_poc
        else:
            scores['dir_poc'] = 0.0
        
        # VAH/VAL touch: bullish if VAH not touched, bearish if VAL not touched
        if w.use_dir_vah_val:
            if not state.vah_touched_today:
                raw_vah_val = 1.0
            elif not state.val_touched_today:
                raw_vah_val = -1.0
            else:
                raw_vah_val = 0.0
            scores['dir_vah_val'] = raw_vah_val * w.dir_vah_val
        else:
            scores['dir_vah_val'] = 0.0
        
        # EMA positions
        if w.use_dir_ema9:
            scores['dir_ema9'] = (1.0 if state.close > state.ema9 else -1.0) * w.dir_ema9
        else:
            scores['dir_ema9'] = 0.0
            
        if w.use_dir_ema21:
            scores['dir_ema21'] = (1.0 if state.close > state.ema21 else -1.0) * w.dir_ema21
        else:
            scores['dir_ema21'] = 0.0
            
        if w.use_dir_ema50:
            scores['dir_ema50'] = (1.0 if state.close > state.ema50 else -1.0) * w.dir_ema50
        else:
            scores['dir_ema50'] = 0.0
        
        # Box breakout
        if w.use_dir_box_break:
            if state.normal_box_break_up:
                raw_box = 1.0
            elif state.normal_box_break_down:
                raw_box = -1.0
            else:
                raw_box = 0.0
            scores['dir_box_break'] = raw_box * w.dir_box_break
        else:
            scores['dir_box_break'] = 0.0
        
        # Volume spike (binary - just confirms direction)
        if w.use_dir_volume:
            vol_ok = state.volume >= state.volume_avg * w.volume_filter_mult
            scores['dir_volume'] = (1.0 if vol_ok else 0.0) * w.dir_volume
        else:
            scores['dir_volume'] = 0.0
        
        # VWAP reversion
        if w.use_dir_vwap_rev:
            vwap_range = state.vwap_upper_band - state.vwap_lower_band
            if vwap_range > 0:
                vwap_pos_pct = ((state.close - state.vwap_lower_band) / vwap_range) * 100
                vwap_rev_zone = 80.0
                if vwap_pos_pct >= vwap_rev_zone:
                    raw_vwap = -1.0  # Overbought, expect reversion down
                elif vwap_pos_pct <= (100 - vwap_rev_zone):
                    raw_vwap = 1.0   # Oversold, expect reversion up
                else:
                    raw_vwap = 0.0
            else:
                raw_vwap = 0.0
            scores['dir_vwap_rev'] = raw_vwap * w.dir_vwap_rev
        else:
            scores['dir_vwap_rev'] = 0.0
        
        raw_total = sum(scores.values())
        weighted_total = raw_total * w.dir_category_weight
        
        return weighted_total, scores
    
    def calculate_momentum_scores(self, state: IndicatorState) -> Tuple[float, Dict[str, float]]:
        """Calculate momentum category scores"""
        w = self.weights
        scores = {}
        
        # EMA trend (9 vs 21)
        if w.use_mom_ema_trend:
            ema_uptrend = state.ema9 >= state.ema21
            scores['mom_ema_trend'] = (1.0 if ema_uptrend else -1.0) * w.mom_ema_trend
        else:
            scores['mom_ema_trend'] = 0.0
        
        # KC position
        if w.use_mom_kc:
            if state.close > state.kc_upper:
                raw_kc = 1.0
            elif state.close < state.kc_lower:
                raw_kc = -1.0
            else:
                raw_kc = 0.0
            scores['mom_kc'] = raw_kc * w.mom_kc
        else:
            scores['mom_kc'] = 0.0
        
        # BB position
        if w.use_mom_bb:
            if state.close > state.bb_upper:
                raw_bb = 1.0
            elif state.close < state.bb_lower:
                raw_bb = -1.0
            else:
                raw_bb = 0.0
            scores['mom_bb'] = raw_bb * w.mom_bb
        else:
            scores['mom_bb'] = 0.0
        
        # VWAP band position
        if w.use_mom_vwap_band:
            if state.close > state.vwap_upper_band:
                raw_vwap = 1.0
            elif state.close < state.vwap_lower_band:
                raw_vwap = -1.0
            else:
                raw_vwap = 0.0
            scores['mom_vwap_band'] = raw_vwap * w.mom_vwap_band
        else:
            scores['mom_vwap_band'] = 0.0
        
        # Candle close position
        if w.use_mom_candle:
            if state.close_in_upper_third:
                raw_candle = 1.0
            elif state.close_in_lower_third:
                raw_candle = -1.0
            else:
                raw_candle = 0.0
            scores['mom_candle'] = raw_candle * w.mom_candle
        else:
            scores['mom_candle'] = 0.0
        
        raw_total = sum(scores.values())
        weighted_total = raw_total * w.mom_category_weight
        
        return weighted_total, scores
    
    def calculate_breakout_scores(self, state: IndicatorState) -> Tuple[float, Dict[str, float]]:
        """Calculate breakout category scores"""
        w = self.weights
        scores = {}
        
        # Squeeze (BB inside KC)
        if w.use_bo_squeeze:
            raw_squeeze = 1.0 if state.squeeze_active else 0.0
            scores['bo_squeeze'] = raw_squeeze * w.bo_squeeze
        else:
            scores['bo_squeeze'] = 0.0
        
        # Box edge position
        if w.use_bo_box_pos:
            box_range = state.normal_box_high - state.normal_box_low
            box_edge_threshold = 0.20  # 20%
            if state.normal_box_active and box_range > 0:
                box_edge_size = box_range * box_edge_threshold
                if state.close >= (state.normal_box_high - box_edge_size):
                    raw_box_pos = 1.0
                elif state.close <= (state.normal_box_low + box_edge_size):
                    raw_box_pos = -1.0
                else:
                    raw_box_pos = 0.0
            else:
                raw_box_pos = 0.0
            scores['bo_box_pos'] = raw_box_pos * w.bo_box_pos
        else:
            scores['bo_box_pos'] = 0.0
        
        raw_total = sum(scores.values())
        weighted_total = raw_total * w.bo_category_weight
        
        return weighted_total, scores
    
    def calculate_price_action_scores(self, state: IndicatorState) -> Tuple[float, Dict[str, float]]:
        """Calculate price action category scores"""
        w = self.weights
        scores = {}
        
        # Swing breakouts
        if w.use_pa_swing_high:
            scores['pa_swing_high'] = (1.0 if state.swing_high_breakout else 0.0) * w.pa_swing_high
        else:
            scores['pa_swing_high'] = 0.0
            
        if w.use_pa_swing_low:
            scores['pa_swing_low'] = (-1.0 if state.swing_low_breakout else 0.0) * w.pa_swing_low
        else:
            scores['pa_swing_low'] = 0.0
        
        # PDH/PDL breaks
        if w.use_pa_pdh_pdl:
            scores['pa_pdh'] = (1.0 if state.pdh_break else 0.0) * w.pa_pdh_pdl
            scores['pa_pdl'] = (-1.0 if state.pdl_break else 0.0) * w.pa_pdh_pdl
        else:
            scores['pa_pdh'] = 0.0
            scores['pa_pdl'] = 0.0
        
        # PWH/PWL breaks
        if w.use_pa_pwh_pwl:
            scores['pa_pwh'] = (1.0 if state.pwh_break else 0.0) * w.pa_pwh_pwl
            scores['pa_pwl'] = (-1.0 if state.pwl_break else 0.0) * w.pa_pwh_pwl
        else:
            scores['pa_pwh'] = 0.0
            scores['pa_pwl'] = 0.0
        
        # Swing proximity
        if w.use_pa_swing_proximity:
            scores['pa_swing_prox_high'] = (1.0 if state.swing_high_proximity else 0.0) * w.pa_swing_proximity
            scores['pa_swing_prox_low'] = (-1.0 if state.swing_low_proximity else 0.0) * w.pa_swing_proximity
        else:
            scores['pa_swing_prox_high'] = 0.0
            scores['pa_swing_prox_low'] = 0.0
        
        raw_total = sum(scores.values())
        weighted_total = raw_total * w.pa_category_weight
        
        return weighted_total, scores
    
    def calculate_key_level_scores(self, state: IndicatorState) -> Tuple[float, Dict[str, float]]:
        """Calculate key level confluence scores"""
        w = self.weights
        scores = {}
        
        proximity_pct = 0.003  # 0.3%
        proximity_zone = state.close * proximity_pct
        
        # Track which levels are near for stack calculation
        near_daily = False
        near_weekly = False
        near_monthly = False
        near_ny = False
        
        # Daily open proximity
        if w.use_kl_daily:
            near_daily = abs(state.close - state.daily_open) <= proximity_zone if state.daily_open else False
            scores['kl_daily'] = (1.0 if near_daily else 0.0) * w.kl_daily
        else:
            scores['kl_daily'] = 0.0
        
        # Weekly open proximity
        if w.use_kl_weekly:
            near_weekly = abs(state.close - state.weekly_open) <= proximity_zone if state.weekly_open else False
            scores['kl_weekly'] = (1.0 if near_weekly else 0.0) * w.kl_weekly
        else:
            scores['kl_weekly'] = 0.0
        
        # Monthly open proximity
        if w.use_kl_monthly:
            near_monthly = abs(state.close - state.monthly_open) <= proximity_zone if state.monthly_open else False
            scores['kl_monthly'] = (1.0 if near_monthly else 0.0) * w.kl_monthly
        else:
            scores['kl_monthly'] = 0.0
        
        # NY open proximity
        if w.use_kl_ny:
            near_ny = abs(state.close - state.ny_open) <= proximity_zone if state.ny_open else False
            scores['kl_ny'] = (1.0 if near_ny else 0.0) * w.kl_ny
        else:
            scores['kl_ny'] = 0.0
        
        # Level stack (2+ levels near)
        if w.use_kl_stack:
            level_count = sum([near_daily, near_weekly, near_monthly, near_ny])
            level_stack = level_count >= 2
            scores['kl_stack'] = (1.0 if level_stack else 0.0) * w.kl_stack
        else:
            scores['kl_stack'] = 0.0
        
        raw_total = sum(scores.values())
        weighted_total = raw_total * w.kl_category_weight
        
        return weighted_total, scores
    
    def calculate_total_score(self, state: IndicatorState) -> ScoreBreakdown:
        """Calculate all scores and determine signal"""
        breakdown = ScoreBreakdown()
        
        # Direction
        dir_weighted, dir_scores = self.calculate_direction_scores(state)
        breakdown.dir_poc = dir_scores.get('dir_poc', 0)
        breakdown.dir_vah_val = dir_scores.get('dir_vah_val', 0)
        breakdown.dir_ema9 = dir_scores.get('dir_ema9', 0)
        breakdown.dir_ema21 = dir_scores.get('dir_ema21', 0)
        breakdown.dir_ema50 = dir_scores.get('dir_ema50', 0)
        breakdown.dir_box_break = dir_scores.get('dir_box_break', 0)
        breakdown.dir_volume = dir_scores.get('dir_volume', 0)
        breakdown.dir_vwap_rev = dir_scores.get('dir_vwap_rev', 0)
        breakdown.direction_raw = sum(dir_scores.values())
        breakdown.direction_weighted = dir_weighted
        
        # Momentum
        mom_weighted, mom_scores = self.calculate_momentum_scores(state)
        breakdown.mom_ema_trend = mom_scores.get('mom_ema_trend', 0)
        breakdown.mom_kc = mom_scores.get('mom_kc', 0)
        breakdown.mom_bb = mom_scores.get('mom_bb', 0)
        breakdown.mom_vwap_band = mom_scores.get('mom_vwap_band', 0)
        breakdown.mom_candle = mom_scores.get('mom_candle', 0)
        breakdown.momentum_raw = sum(mom_scores.values())
        breakdown.momentum_weighted = mom_weighted
        
        # Breakout
        bo_weighted, bo_scores = self.calculate_breakout_scores(state)
        breakdown.bo_squeeze = bo_scores.get('bo_squeeze', 0)
        breakdown.bo_box_pos = bo_scores.get('bo_box_pos', 0)
        breakdown.breakout_raw = sum(bo_scores.values())
        breakdown.breakout_weighted = bo_weighted
        
        # Price Action
        pa_weighted, pa_scores = self.calculate_price_action_scores(state)
        breakdown.pa_swing_high = pa_scores.get('pa_swing_high', 0)
        breakdown.pa_swing_low = pa_scores.get('pa_swing_low', 0)
        breakdown.pa_pdh = pa_scores.get('pa_pdh', 0)
        breakdown.pa_pdl = pa_scores.get('pa_pdl', 0)
        breakdown.pa_pwh = pa_scores.get('pa_pwh', 0)
        breakdown.pa_pwl = pa_scores.get('pa_pwl', 0)
        breakdown.pa_swing_prox_high = pa_scores.get('pa_swing_prox_high', 0)
        breakdown.pa_swing_prox_low = pa_scores.get('pa_swing_prox_low', 0)
        breakdown.price_action_raw = sum(pa_scores.values())
        breakdown.price_action_weighted = pa_weighted
        
        # Key Levels
        kl_weighted, kl_scores = self.calculate_key_level_scores(state)
        breakdown.kl_daily = kl_scores.get('kl_daily', 0)
        breakdown.kl_weekly = kl_scores.get('kl_weekly', 0)
        breakdown.kl_monthly = kl_scores.get('kl_monthly', 0)
        breakdown.kl_ny = kl_scores.get('kl_ny', 0)
        breakdown.kl_stack = kl_scores.get('kl_stack', 0)
        breakdown.key_level_raw = sum(kl_scores.values())
        breakdown.key_level_weighted = kl_weighted
        
        # Total
        breakdown.total_score = (
            dir_weighted + mom_weighted + bo_weighted + 
            pa_weighted + kl_weighted
        )
        
        # Determine signal
        min_strength = self.weights.entry_strength_min
        if breakdown.total_score >= min_strength:
            breakdown.signal = Signal.STRONG_BUY
        elif breakdown.total_score > 0:
            breakdown.signal = Signal.LEAN_LONG
        elif breakdown.total_score <= -min_strength:
            breakdown.signal = Signal.STRONG_SELL
        elif breakdown.total_score < 0:
            breakdown.signal = Signal.LEAN_SHORT
        else:
            breakdown.signal = Signal.NEUTRAL
        
        return breakdown


def calculate_indicators_from_ohlcv(df: pd.DataFrame) -> IndicatorState:
    """
    Calculate all indicators from OHLCV DataFrame.
    
    Expected columns: timestamp, open, high, low, close, volume
    Should have at least 200 rows for accurate EMA calculations.
    """
    if len(df) < 50:
        raise ValueError("Need at least 50 bars of data for indicator calculation")
    
    state = IndicatorState()
    
    # Latest bar
    state.close = df['close'].iloc[-1]
    state.high = df['high'].iloc[-1]
    state.low = df['low'].iloc[-1]
    state.open = df['open'].iloc[-1]
    state.volume = df['volume'].iloc[-1]
    
    # EMAs
    state.ema9 = df['close'].ewm(span=9, adjust=False).mean().iloc[-1]
    state.ema21 = df['close'].ewm(span=21, adjust=False).mean().iloc[-1]
    state.ema50 = df['close'].ewm(span=50, adjust=False).mean().iloc[-1]
    
    # Volume average
    state.volume_avg = df['volume'].rolling(20).mean().iloc[-1]
    
    # ATR
    tr = pd.DataFrame()
    tr['hl'] = df['high'] - df['low']
    tr['hc'] = abs(df['high'] - df['close'].shift(1))
    tr['lc'] = abs(df['low'] - df['close'].shift(1))
    tr['tr'] = tr[['hl', 'hc', 'lc']].max(axis=1)
    state.atr = tr['tr'].rolling(14).mean().iloc[-1]
    
    # Bollinger Bands
    bb_length = 20
    bb_mult = 2.0
    bb_basis = df['close'].rolling(bb_length).mean()
    bb_dev = df['close'].rolling(bb_length).std() * bb_mult
    state.bb_upper = (bb_basis + bb_dev).iloc[-1]
    state.bb_lower = (bb_basis - bb_dev).iloc[-1]
    state.bb_width = state.bb_upper - state.bb_lower
    
    # Keltner Channels
    kc_length = 20
    kc_mult = 2.0
    kc_atr_len = 10
    kc_ma = df['close'].ewm(span=kc_length, adjust=False).mean()
    kc_atr = tr['tr'].rolling(kc_atr_len).mean()
    state.kc_upper = (kc_ma + kc_atr * kc_mult).iloc[-1]
    state.kc_lower = (kc_ma - kc_atr * kc_mult).iloc[-1]
    
    # Squeeze detection (BB inside KC)
    bb_contracting = state.bb_width < df['close'].rolling(10).std().iloc[-1] * 2 * 2
    kc_range = state.kc_upper - state.kc_lower
    kc_prox_zone = kc_range * 0.20
    state.price_near_kc_upper = state.high >= state.kc_upper - kc_prox_zone
    state.price_near_kc_lower = state.low <= state.kc_lower + kc_prox_zone
    state.squeeze_active = (state.price_near_kc_upper or state.price_near_kc_lower) and bb_contracting
    
    # Candle position
    candle_range = state.high - state.low
    body_pct = 0.30
    if candle_range > 0:
        state.close_in_upper_third = state.close >= state.high - candle_range * body_pct
        state.close_in_lower_third = state.close <= state.low + candle_range * body_pct
    
    return state


if __name__ == "__main__":
    # Example usage
    weights = WeightConfig()
    engine = ScoringEngine(weights)
    
    # Create a test state
    state = IndicatorState(
        close=71000,
        high=71500,
        low=70500,
        open=70800,
        volume=1500,
        ema9=70800,
        ema21=70600,
        ema50=70000,
        poc=70500,
        vah=71200,
        val=70200,
        vwap=70700,
        vwap_upper_band=71300,
        vwap_lower_band=70100,
        bb_upper=71400,
        bb_lower=70100,
        kc_upper=71200,
        kc_lower=70300,
        volume_avg=1000,
        daily_open=70600,
        weekly_open=69500,
    )
    
    breakdown = engine.calculate_total_score(state)
    print(f"Total Score: {breakdown.total_score:.2f}")
    print(f"Signal: {breakdown.signal.value}")
    print(f"\nDirection: {breakdown.direction_weighted:.2f}")
    print(f"Momentum: {breakdown.momentum_weighted:.2f}")
    print(f"Breakout: {breakdown.breakout_weighted:.2f}")
    print(f"Price Action: {breakdown.price_action_weighted:.2f}")
    print(f"Key Levels: {breakdown.key_level_weighted:.2f}")
