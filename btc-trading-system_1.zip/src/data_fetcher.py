"""
BTC Data Fetcher - Fetches 15-minute OHLCV data from Binance API

Uses the free Binance public API (no API key required for market data).
"""

import requests
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, Dict, List
import time


class BinanceDataFetcher:
    """Fetches BTC/USDT OHLCV data from Binance public API"""
    
    BASE_URL = "https://api.binance.com/api/v3"
    SYMBOL = "BTCUSDT"
    
    def __init__(self):
        self.session = requests.Session()
    
    def fetch_klines(
        self, 
        interval: str = "15m",
        limit: int = 200,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None
    ) -> pd.DataFrame:
        """
        Fetch candlestick data from Binance.
        
        Args:
            interval: Kline interval (1m, 5m, 15m, 1h, 4h, 1d, etc.)
            limit: Number of candles (max 1000)
            start_time: Start time in milliseconds
            end_time: End time in milliseconds
            
        Returns:
            DataFrame with columns: timestamp, open, high, low, close, volume
        """
        params = {
            "symbol": self.SYMBOL,
            "interval": interval,
            "limit": min(limit, 1000)
        }
        
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time
        
        response = self.session.get(f"{self.BASE_URL}/klines", params=params)
        response.raise_for_status()
        
        data = response.json()
        
        df = pd.DataFrame(data, columns=[
            'timestamp', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_volume', 'trades', 'taker_buy_base',
            'taker_buy_quote', 'ignore'
        ])
        
        # Convert types
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        for col in ['open', 'high', 'low', 'close', 'volume']:
            df[col] = df[col].astype(float)
        
        # Keep only needed columns
        df = df[['timestamp', 'open', 'high', 'low', 'close', 'volume']]
        
        return df
    
    def fetch_current_price(self) -> float:
        """Fetch current BTC price"""
        response = self.session.get(
            f"{self.BASE_URL}/ticker/price",
            params={"symbol": self.SYMBOL}
        )
        response.raise_for_status()
        return float(response.json()['price'])
    
    def fetch_24h_stats(self) -> Dict:
        """Fetch 24-hour price statistics"""
        response = self.session.get(
            f"{self.BASE_URL}/ticker/24hr",
            params={"symbol": self.SYMBOL}
        )
        response.raise_for_status()
        data = response.json()
        
        return {
            "price": float(data['lastPrice']),
            "high_24h": float(data['highPrice']),
            "low_24h": float(data['lowPrice']),
            "volume_24h": float(data['volume']),
            "price_change_pct": float(data['priceChangePercent']),
        }
    
    def fetch_historical_range(
        self,
        interval: str = "15m",
        days_back: int = 7
    ) -> pd.DataFrame:
        """
        Fetch historical data for a specified number of days.
        
        Args:
            interval: Kline interval
            days_back: Number of days to fetch
            
        Returns:
            DataFrame with OHLCV data
        """
        end_time = int(datetime.now().timestamp() * 1000)
        start_time = int((datetime.now() - timedelta(days=days_back)).timestamp() * 1000)
        
        all_data = []
        current_start = start_time
        
        while current_start < end_time:
            df = self.fetch_klines(
                interval=interval,
                limit=1000,
                start_time=current_start,
                end_time=end_time
            )
            
            if df.empty:
                break
            
            all_data.append(df)
            
            # Move start time to after last candle
            last_ts = int(df['timestamp'].iloc[-1].timestamp() * 1000)
            current_start = last_ts + 1
            
            # Rate limit
            time.sleep(0.1)
        
        if not all_data:
            return pd.DataFrame()
        
        return pd.concat(all_data, ignore_index=True).drop_duplicates(subset=['timestamp'])


class CoinalyzeDataFetcher:
    """
    Coinalyze data handler - stores and analyzes derivative market data.
    
    Data is extracted via Chrome MCP network interception or manually entered
    from the Coinalyze dashboard (https://coinalyze.net/bitcoin/).
    
    Key metrics tracked:
    - Open Interest ($bn): Total value of outstanding futures contracts
    - Funding Rate: Periodic payment between longs/shorts (positive = longs pay)
    - Liquidations: Forced position closures by amount and direction
    - CVD Futures: Cumulative Volume Delta for perpetual futures
    - CVD Spot: Cumulative Volume Delta for spot markets
    - CME OI: CME futures open interest (institutional indicator)
    """
    
    def __init__(self):
        self.data = {}
        self.history = []  # Store historical data points
    
    def set_data(
        self,
        open_interest: Optional[float] = None,        # Total OI in $bn
        funding_rate: Optional[float] = None,          # e.g., 0.0044 = 0.44%
        liquidations_total: Optional[float] = None,    # Total liqs in millions/thousands
        liquidations_long: Optional[float] = None,     # Long liqs
        liquidations_short: Optional[float] = None,    # Short liqs  
        cvd_futures: Optional[float] = None,           # CVD Futs delta (green bar value)
        cvd_futures_cumulative: Optional[float] = None,# CVD Futs cumulative (orange line)
        cvd_spot: Optional[float] = None,              # CVD Spot delta
        cvd_spot_cumulative: Optional[float] = None,   # CVD Spot cumulative
        cme_oi: Optional[float] = None,                # CME OI in $bn
        btc_price: Optional[float] = None,             # BTC price at time of data
        timestamp: Optional[str] = None                # ISO timestamp
    ):
        """Set Coinalyze data from external source (screenshot, API, Chrome MCP)"""
        
        if open_interest is not None:
            self.data['open_interest'] = open_interest
        if funding_rate is not None:
            self.data['funding_rate'] = funding_rate
        if liquidations_total is not None:
            self.data['liquidations_total'] = liquidations_total
        if liquidations_long is not None:
            self.data['liquidations_long'] = liquidations_long
        if liquidations_short is not None:
            self.data['liquidations_short'] = liquidations_short
        if cvd_futures is not None:
            self.data['cvd_futures'] = cvd_futures
        if cvd_futures_cumulative is not None:
            self.data['cvd_futures_cumulative'] = cvd_futures_cumulative
        if cvd_spot is not None:
            self.data['cvd_spot'] = cvd_spot
        if cvd_spot_cumulative is not None:
            self.data['cvd_spot_cumulative'] = cvd_spot_cumulative
        if cme_oi is not None:
            self.data['cme_oi'] = cme_oi
        if btc_price is not None:
            self.data['btc_price'] = btc_price
        if timestamp is not None:
            self.data['timestamp'] = timestamp
        else:
            self.data['timestamp'] = datetime.utcnow().isoformat()
    
    def set_from_screenshot(
        self,
        btc_price: float,
        oi: float,           # e.g., 22.479 (in $bn)
        funding: float,      # e.g., 0.0044
        liqs: float,         # e.g., 50.913 (in K)
        cvd_futs_delta: float,  # e.g., 11.231 (green bar, in M)
        cvd_spot_delta: float,  # e.g., 418 (green bar)
        cvd_futs_cumulative: float = 0.0,  # Orange line value
        cvd_spot_cumulative: float = 0.0,  # Cumulative spot
    ):
        """
        Convenience method to set data from Coinalyze screenshot values.
        
        Values are read directly from the dashboard display.
        """
        self.set_data(
            btc_price=btc_price,
            open_interest=oi,
            funding_rate=funding,
            liquidations_total=liqs,
            cvd_futures=cvd_futs_delta,
            cvd_futures_cumulative=cvd_futs_cumulative,
            cvd_spot=cvd_spot_delta,
            cvd_spot_cumulative=cvd_spot_cumulative,
        )
    
    def get_data(self) -> Dict:
        """Get all Coinalyze data"""
        return self.data.copy()
    
    def analyze_cvd_vs_price(self, price_change_pct: float) -> str:
        """
        Analyze CVD divergence from price.
        
        Args:
            price_change_pct: Price change percentage (e.g., 1.5 for +1.5%)
            
        Returns:
            'Bullish Divergence', 'Bearish Divergence', 'Confirming', or 'Neutral'
        """
        cvd_futs = self.data.get('cvd_futures', 0)
        
        # Determine CVD direction
        cvd_bullish = cvd_futs > 0
        price_bullish = price_change_pct > 0
        
        if cvd_bullish and not price_bullish:
            return "Bullish Divergence"  # CVD up but price down - accumulation
        elif not cvd_bullish and price_bullish:
            return "Bearish Divergence"  # CVD down but price up - distribution
        elif cvd_bullish and price_bullish:
            return "Confirming Up"
        elif not cvd_bullish and not price_bullish:
            return "Confirming Down"
        else:
            return "Neutral"
    
    def analyze_oi_vs_price(self, price_change_pct: float, oi_change_pct: float) -> str:
        """
        Analyze Open Interest relative to price movement.
        
        Args:
            price_change_pct: Price change percentage
            oi_change_pct: OI change percentage
            
        Returns:
            Interpretation string
        """
        # Classic OI interpretation:
        # Price up + OI up = New longs (bullish)
        # Price up + OI down = Short covering (weak bullish)
        # Price down + OI up = New shorts (bearish)
        # Price down + OI down = Long liquidation (weak bearish)
        
        price_up = price_change_pct > 0
        oi_up = oi_change_pct > 0
        
        if price_up and oi_up:
            return "New Longs"
        elif price_up and not oi_up:
            return "Short Covering"
        elif not price_up and oi_up:
            return "New Shorts"
        else:
            return "Long Liquidation"
    
    def get_funding_sentiment(self) -> str:
        """
        Interpret funding rate sentiment.
        
        Returns:
            'Extremely Bullish', 'Bullish', 'Neutral', 'Bearish', 'Extremely Bearish'
        """
        funding = self.data.get('funding_rate', 0)
        
        if funding > 0.02:
            return "Extremely Bullish"
        elif funding > 0.005:
            return "Bullish"
        elif funding > -0.005:
            return "Neutral"
        elif funding > -0.02:
            return "Bearish"
        else:
            return "Extremely Bearish"
    
    def parse_from_chrome_mcp(self, network_data: List[Dict]) -> Dict:
        """
        Parse Coinalyze data from Chrome MCP network requests.
        
        This method will be called with the results from Chrome MCP's
        read_network_requests tool after navigating to Coinalyze.
        
        Args:
            network_data: List of network request/response data
            
        Returns:
            Parsed Coinalyze metrics
        """
        parsed = {}
        
        for request in network_data:
            url = request.get('url', '')
            
            # Look for Coinalyze API endpoints
            if 'coinalyze.net' in url or 'coinalyze' in url:
                # Parse response body
                body = request.get('responseBody', {})
                
                # Extract metrics based on endpoint
                if 'open-interest' in url or 'oi' in url:
                    if isinstance(body, dict):
                        parsed['open_interest'] = body.get('value')
                
                if 'funding' in url:
                    if isinstance(body, dict):
                        parsed['funding_rate'] = body.get('value')
                
                if 'liquidation' in url:
                    if isinstance(body, dict):
                        parsed['liquidations_long'] = body.get('long', 0)
                        parsed['liquidations_short'] = body.get('short', 0)
                        parsed['liquidations_total'] = body.get('total', 0)
                
                if 'cvd' in url:
                    if isinstance(body, dict):
                        if 'futures' in url or 'futs' in url:
                            parsed['cvd_futures'] = body.get('value')
                        elif 'spot' in url:
                            parsed['cvd_spot'] = body.get('value')
        
        self.data.update(parsed)
        return parsed
    
    def to_airtable_fields(self) -> Dict:
        """
        Convert Coinalyze data to Airtable field format.
        
        Field mappings for table 'Just nu daily data & intra day data':
        - fld5kPXlCUF9v8qoj = BTC price
        - fldDXTQLutuc1kmMx = OI ($bn)
        - fldM6t0ftIDJWdCjy = Funding
        - fldYlvB3mniCFeCVh = Liqs (prev day)
        - fldqsVTSXrUFahAh7 = CVD Futs  
        - fldgEKgDJgaZhvzpf = CVD Spot
        - fldcFH9HV8ocWt1lb = CME OI ($bn)
        """
        return {
            'fld5kPXlCUF9v8qoj': self.data.get('btc_price'),
            'fldDXTQLutuc1kmMx': self.data.get('open_interest'),
            'fldM6t0ftIDJWdCjy': self.data.get('funding_rate'),
            'fldYlvB3mniCFeCVh': self.data.get('liquidations_total'),
            'fldqsVTSXrUFahAh7': self.data.get('cvd_futures'),
            'fldgEKgDJgaZhvzpf': self.data.get('cvd_spot'),
            'fldcFH9HV8ocWt1lb': self.data.get('cme_oi'),
        }


def calculate_key_levels(df: pd.DataFrame) -> Dict:
    """
    Calculate key price levels from OHLCV data.
    
    Args:
        df: DataFrame with timestamp, open, high, low, close columns
        
    Returns:
        Dictionary of key levels
    """
    if df.empty:
        return {}
    
    # Ensure timestamp is datetime
    if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
        df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    df = df.sort_values('timestamp')
    now = df['timestamp'].iloc[-1]
    
    levels = {}
    
    # Daily levels
    today_start = now.normalize()
    yesterday_start = today_start - timedelta(days=1)
    
    yesterday_data = df[(df['timestamp'] >= yesterday_start) & (df['timestamp'] < today_start)]
    if not yesterday_data.empty:
        levels['prev_day_high'] = yesterday_data['high'].max()
        levels['prev_day_low'] = yesterday_data['low'].min()
    
    today_data = df[df['timestamp'] >= today_start]
    if not today_data.empty:
        levels['daily_open'] = today_data['open'].iloc[0]
    
    # Weekly levels
    week_start = now - timedelta(days=now.weekday())
    week_start = week_start.normalize()
    prev_week_start = week_start - timedelta(days=7)
    
    prev_week_data = df[(df['timestamp'] >= prev_week_start) & (df['timestamp'] < week_start)]
    if not prev_week_data.empty:
        levels['prev_week_high'] = prev_week_data['high'].max()
        levels['prev_week_low'] = prev_week_data['low'].min()
    
    this_week_data = df[df['timestamp'] >= week_start]
    if not this_week_data.empty:
        levels['weekly_open'] = this_week_data['open'].iloc[0]
    
    # Monthly levels
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    prev_month_start = (month_start - timedelta(days=1)).replace(day=1)
    
    prev_month_data = df[(df['timestamp'] >= prev_month_start) & (df['timestamp'] < month_start)]
    if not prev_month_data.empty:
        levels['prev_month_high'] = prev_month_data['high'].max()
        levels['prev_month_low'] = prev_month_data['low'].min()
    
    this_month_data = df[df['timestamp'] >= month_start]
    if not this_month_data.empty:
        levels['monthly_open'] = this_month_data['open'].iloc[0]
    
    return levels


def detect_swing_levels(df: pd.DataFrame, lookback: int = 14) -> Dict:
    """
    Detect swing high and low levels.
    
    Args:
        df: OHLCV DataFrame
        lookback: Number of bars to look back for pivots
        
    Returns:
        Dictionary with swing_high_top, swing_low_btm, etc.
    """
    if len(df) < lookback * 2 + 1:
        return {}
    
    highs = df['high'].values
    lows = df['low'].values
    
    swing_high = None
    swing_low = None
    
    # Find most recent pivot high
    for i in range(len(highs) - lookback - 1, lookback - 1, -1):
        is_pivot_high = True
        for j in range(1, lookback + 1):
            if highs[i] <= highs[i - j] or highs[i] <= highs[i + j]:
                is_pivot_high = False
                break
        if is_pivot_high:
            swing_high = highs[i]
            break
    
    # Find most recent pivot low
    for i in range(len(lows) - lookback - 1, lookback - 1, -1):
        is_pivot_low = True
        for j in range(1, lookback + 1):
            if lows[i] >= lows[i - j] or lows[i] >= lows[i + j]:
                is_pivot_low = False
                break
        if is_pivot_low:
            swing_low = lows[i]
            break
    
    current_close = df['close'].iloc[-1]
    current_high = df['high'].iloc[-1]
    current_low = df['low'].iloc[-1]
    
    result = {}
    
    if swing_high:
        result['swing_high_top'] = swing_high
        result['swing_high_broken'] = current_close > swing_high
        result['swing_high_breakout'] = (
            current_close > swing_high and 
            df['close'].iloc[-2] <= swing_high
        )
        proximity_pct = 0.003
        result['swing_high_proximity'] = (
            current_high >= swing_high * (1 - proximity_pct) and
            current_close < swing_high
        )
    
    if swing_low:
        result['swing_low_btm'] = swing_low
        result['swing_low_broken'] = current_close < swing_low
        result['swing_low_breakout'] = (
            current_close < swing_low and
            df['close'].iloc[-2] >= swing_low
        )
        proximity_pct = 0.003
        result['swing_low_proximity'] = (
            current_low <= swing_low * (1 + proximity_pct) and
            current_close > swing_low
        )
    
    return result


if __name__ == "__main__":
    # Test the data fetcher
    fetcher = BinanceDataFetcher()
    
    print("Fetching current BTC price...")
    price = fetcher.fetch_current_price()
    print(f"Current BTC price: ${price:,.2f}")
    
    print("\nFetching 15m candles...")
    df = fetcher.fetch_klines(interval="15m", limit=100)
    print(f"Got {len(df)} candles")
    print(df.tail())
    
    print("\nCalculating key levels...")
    levels = calculate_key_levels(df)
    for key, value in levels.items():
        print(f"  {key}: ${value:,.2f}")
    
    print("\nDetecting swing levels...")
    swings = detect_swing_levels(df)
    for key, value in swings.items():
        if isinstance(value, float):
            print(f"  {key}: ${value:,.2f}")
        else:
            print(f"  {key}: {value}")
