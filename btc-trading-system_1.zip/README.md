# BTC Multi-Box Breakout Trading System

A Python implementation of the TradingView Pine Script "BTC Multi-Box Breakout Strategy v6", designed to run independently and sync with Airtable for automated trading signals.

## 🎯 Overview

This system calculates weighted trading signals based on 5 indicator categories:

| Category | Indicators | Default Weight |
|----------|-----------|----------------|
| **Direction** | POC position, VAH/VAL, EMA 9/21/50, Box breakout, Volume, VWAP reversion | 1.0× |
| **Momentum** | EMA trend, KC position, BB position, VWAP band, Candle close | 1.0× |
| **Breakout** | BB+KC squeeze, Box edge position | 1.0× |
| **Price Action** | Swing H/L breaks, PDH/PDL, PWH/PWL | 1.0× |
| **Key Levels** | Daily/Weekly/Monthly opens, Level stacks | 1.0× |

### Signal Logic

- **STRONG BUY**: Total score ≥ +5.0
- **LEAN LONG**: Score > 0 but < +5.0
- **NEUTRAL**: Score = 0
- **LEAN SHORT**: Score < 0 but > -5.0
- **STRONG SELL**: Total score ≤ -5.0

## 📁 Project Structure

```
btc-trading-system/
├── src/
│   ├── scoring_engine.py    # Core scoring logic (mirrors Pine Script v6)
│   ├── data_fetcher.py      # Binance API + Coinalyze data
│   ├── airtable_client.py   # Airtable integration
│   └── main.py              # Main orchestration script
├── .github/
│   └── workflows/
│       └── trading_pipeline.yml  # GitHub Actions (runs every 15 mins)
├── requirements.txt
└── README.md
```

## 🚀 Quick Start

### 1. Clone and Install

```bash
git clone https://github.com/YOUR_USERNAME/btc-trading-system.git
cd btc-trading-system
pip install -r requirements.txt
```

### 2. Set Environment Variables

```bash
# Required for Airtable upload
export AIRTABLE_API_KEY="your_airtable_api_key"
```

### 3. Run

```bash
# Single run (dry run - no Airtable upload)
python src/main.py --dry-run

# Single run with Airtable upload
python src/main.py

# Use a specific entry mode
python src/main.py --mode scalper

# Continuous mode (every 15 minutes)
python src/main.py --continuous

# List all available modes
python src/main.py --list-modes
```

## 🎚️ Entry Mode Presets (v6)

The system supports preset modes matching TradingView v6:

| Mode | Description | Entry Threshold | R:R Min |
|------|-------------|-----------------|---------|
| `full_system` | All indicators enabled with balanced weights | 5.0 | 1.5 |
| `price_action` | Swing breaks, PDH/PDL, PWH/PWL focus | 5.0 | 1.5 |
| `momentum` | EMA trend, KC, BB, VWAP bands focus | 5.0 | 1.5 |
| `volume_profile` | POC, VAH/VAL, volume-based signals | 5.0 | 1.5 |
| `scalper` | Fast signals: EMA, squeeze, volume spikes | 3.0 | 1.0 |
| `swing_trader` | Larger moves: Weekly levels, EMA50 | 5.0 | 2.0 |
| `breakout_hunter` | Box breaks, squeezes, swing breakouts | 4.0 | 1.5 |
| `conservative` | High conviction: Multiple confirmations | 7.0 | 2.0 |
| `custom` | Manual configuration via WeightConfig | 5.0 | 1.5 |

```bash
# Use scalper mode for quick signals
python src/main.py --mode scalper

# Use swing trader mode for longer-term setups
python src/main.py --mode swing_trader --continuous
```

## 📊 Airtable Integration

The system uploads to your "Trading" base with these fields:

| Field | Description |
|-------|-------------|
| `BTC` | Current price |
| `Strength from TW` | Total weighted score |
| `EMA trend` | Direction score |
| `KC/BB Squeeze` | Active squeeze indicator |
| `Anomalies` | Auto-generated alerts |

### Airtable Formulas for Signals

Add these formulas to your Airtable:

**Signal Column** (Single Select):
```
IF(
  {Strength from TW} >= 5, "🟢 STRONG BUY",
  IF(
    {Strength from TW} > 0, "🟡 LEAN LONG",
    IF(
      {Strength from TW} <= -5, "🔴 STRONG SELL",
      IF(
        {Strength from TW} < 0, "🟠 LEAN SHORT",
        "⚪ NEUTRAL"
      )
    )
  )
)
```

**Alert Trigger** (Checkbox formula):
```
OR({Strength from TW} >= 5, {Strength from TW} <= -5)
```

## 🔔 Slack Alerts via Airtable

1. In Airtable, go to **Automations**
2. Create trigger: "When record matches conditions"
3. Condition: `{Strength from TW} >= 5` OR `{Strength from TW} <= -5`
4. Action: Send Slack message

Message template:
```
🚨 BTC TRADING SIGNAL

Signal: {Signal}
Score: {Strength from TW}
Price: ${BTC}
Time: {Date}

View: [link to Airtable]
```

## 🔄 GitHub Actions (Automated Runs)

The included workflow runs every 15 minutes during market hours:

```yaml
# .github/workflows/trading_pipeline.yml
on:
  schedule:
    - cron: '*/15 * * * *'  # Every 15 minutes
```

Set these secrets in your GitHub repo:
- `AIRTABLE_API_KEY`

## 🔍 Coinalyze Data Integration

The system is designed to receive Coinalyze data (OI, Funding, CVD, Liquidations) via Chrome MCP browser automation. See `data_fetcher.py` for the parsing interface.

Manual data entry:
```python
from data_fetcher import CoinalyzeDataFetcher

coinalyze = CoinalyzeDataFetcher()
coinalyze.set_data(
    open_interest=22.5e9,     # $22.5B
    funding_rate=0.0044,
    cvd_futures=11.2e6,
    cvd_spot=3561
)
```

## 📈 Example Output

```
============================================================
BTC TRADING SIGNAL - 2026-04-08T15:30:00
============================================================

📊 BTC Price: $71,234.56

📈 SCORE BREAKDOWN:
   Direction:    +3.50
   Momentum:     +2.00
   Breakout:     +2.00
   Price Action: +1.50
   Key Levels:   +0.00
   ─────────────────────
   TOTAL:        +9.00

🎯 SIGNAL: 🟢🟢 STRONG_BUY

📍 KEY LEVELS:
   Daily Open:   $70,500.00
   PDH:          $71,800.00
   PDL:          $69,200.00

🔧 INDICATORS:
   EMA 9:    $70,950.00 (above)
   EMA 21:   $70,600.00 (above)
   EMA 50:   $69,800.00 (above)
   Squeeze:  No
```

## 📝 License

MIT License - See LICENSE file.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

---

**Note**: This is not financial advice. Use at your own risk. Always do your own research before trading.
